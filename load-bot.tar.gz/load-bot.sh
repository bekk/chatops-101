if [[ "$1" == "ellen" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548445498822-dg8vduQqZ43IgitUcEbBL8pE
elif [[ "$1" == "gaute" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548446868070-K6M1WpjDLsViLdux8Y7pGxaR
elif [[ "$1" == "siri" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-546416649521-J3y5Z8G4hUIHpQEfimKA08yf
elif [[ "$1" == "sara-eline" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548447589766-HT3ghQkimhcyUwA60MFkpcNl
elif [[ "$1" == "kjell-simen" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-546286690672-Rv6GwxBGxURtp5YGPz17XK49
elif [[ "$1" == "ulrik" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-546865595156-blgUuIHvVHDLAcuUVyW6kK84
elif [[ "$1" == "maiken" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-546916127107-16vZBTGRwoppM6Nr9SeFDlDn
elif [[ "$1" == "james" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-547555513345-vR4IfFrr43ZABVgSsV6OkX8L
elif [[ "$1" == "signe" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548044170675-TgsIFIyVRxLIzIk32bqlPK8n
elif [[ "$1" == "gabriel" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-547557141729-Ci4BIW6ApaDkSAPgefrDxXy3
elif [[ "$1" == "katrine" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-547992139396-5oqhAabIkJSc6Lo2qvm7BTl6
elif [[ "$1" == "anita" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548047120467-CkZVfB5lIXBUGHsNGEn0eKvL
elif [[ "$1" == "rainbow" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548367670869-5wNq0DMKKkoNAzbEvomtkU33
elif [[ "$1" == "aslak" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548360860293-J47ycsTnfFft1LCIH32nRdrN
elif [[ "$1" == "kenneth" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-547021853474-mxVZfQOKwB0kGUIyVNkpnvi4
elif [[ "$1" == "birthe" ]]; then
    export HUBOT_SLACK_TOKEN=xoxb-304854357350-548048377907-t3IM2vkk5d9vSa5dgzNv3c7T
else
    echo "No bot specified!"
    exit 1
fi

echo "Slack bot $1 is selected"
